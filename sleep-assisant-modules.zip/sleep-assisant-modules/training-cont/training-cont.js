// components/training-cont/training-cont.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        title:{
            type:String,
            value:"正念聆听"
        },
        img:{
            type:String,
            value:"https://img10.360buyimg.com/n1/s450x450_jfs/t1/86824/3/17907/80506/5e8d726eEd61ffa78/1163f194f235bd83.jpg"
        },
        id:{
            type:String,
            value:""
        },
        cont:{
            type:String,
            value:'缓解您睡前躯体不适,缓解您睡前躯体不适,缓解您睡前躯体不适,缓解您睡前躯体不适,缓解您睡前躯体不适,'
        }
    },

    /**
     * 组件的初始数据
     */
    data: {

    },

    /**
     * 组件的方法列表
     */
    methods: {

    }
})
