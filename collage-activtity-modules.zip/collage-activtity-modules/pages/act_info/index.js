// pages/act1/act1.js
Page({
  data: {
    status:true,
    inform:'报名已结束'
  },
})