
//  不要在 onLaunch 的时候调用 getCurrentPage()此时 page 还没有生成。 
// getCurrentPage是获取当前页面的实例对象。

Page({
  
  data:{
    funny_content: [
      {
        title: "Life is a chess-board",
        content: "The chess-board is the world:the pieces are the phenomena1 of the universe; the rules of the game are what we call the laws of nature. The player on the other side is hidden from us. We know that his play is always fair, just and patient. But also we know, to our cost, that he never overlooks a mistake, or makes the smallest allowance for ignorance.It was the best of times, it was the worst of times; it was the age of wisdom, it was the age of foolishness; it was the epoch1 of belief, it was the epoch of incredulity; it was the season of light, it was the season of darkness; it was the spring of hope, it was the winter of despair; we had everything before us, we had nothing before us; we were all going direct to Heaven, we were all going direct the other way.Between persons of equal income there is no social distinction except the distinction of merit1. Money is nothing;character,conduct,and capacity are everything.Instead of all the workers being leveled down to low wage standards and all the rich leveled up to fashionbale income standards,everybody under a system of equal incomes would find his or her own natural level."
      }
    ]
  }
})



 